function show ()
{ 

	
		var data=document.getElementById("cnt").innerHTML;
		if (data==1)
		{
		document.getElementById("a-2").style.display="block"
		document.getElementById("a-3").style.display="block"
		document.getElementById("a-4").style.display="block"
		document.getElementById("a-5").style.display="block"
		document.getElementById("a-6").style.display="block"
		document.getElementById("cnt").innerHTML=0;
		}
		else
		{		
		document.getElementById("a-2").style.display="none"
		document.getElementById("a-3").style.display="none"
		document.getElementById("a-4").style.display="none"
		document.getElementById("a-5").style.display="none"
		document.getElementById("a-6").style.display="none"
		document.getElementById("cnt").innerHTML=1;
		}
	
	
}
	
	
	function myFunction()
	{
			var wi = window.innerWidth;
			if(wi<=768)
			{
				
				var h11=document.getElementById("a-1");
				//alert(h11);
				// onclick="show()"
				var att=document.createAttribute("onclick");
				att.value="show()";
				h11.setAttributeNode(att);
				// li will have attribute onclick="show()"
				
		document.getElementById("a-2").style.display="none"
		document.getElementById("a-3").style.display="none"
		document.getElementById("a-4").style.display="none"
		document.getElementById("a-5").style.display="none"
		document.getElementById("a-6").style.display="none"
				
				
			}
			else
			{
					
				document.getElementById("a-1").removeAttribute("onclick");
				
					document.getElementById("a-2").style.display="block"
					document.getElementById("a-3").style.display="block"
					document.getElementById("a-4").style.display="block"
					document.getElementById("a-5").style.display="block"
					document.getElementById("a-6").style.display="block"
			}
	}